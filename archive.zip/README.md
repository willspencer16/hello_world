# Introduction to Python :snake:

This repository is me following a LinkedIn Learning tutorial to learn Python.

## Getting Started

The tutorial began with showing how to download Python and run different examples.

## Python Basics

Once Python is installed, the tutorial moved on to the basics of Python. This included:
- Running Python from VS Code
- Variable and expressions
- Python functions
- Conditional structures
- Loops
- Classes
- Importing and using modules

## Next
Working with Dates and Time.
