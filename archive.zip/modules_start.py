
# Importing the math module:
import math

# Using pre-built functions from the math module:
print("The square root of 16 is", math.sqrt(16))
# This uses the math module to find the square root of 16.

#Using pre-built constants from the math module:
print("Pi is:", math.pi)
# This prints the value of pi (a constant)